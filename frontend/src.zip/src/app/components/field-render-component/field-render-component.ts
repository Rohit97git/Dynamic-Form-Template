import { Component } from '@angular/core';

@Component({
  selector: 'app-field-render-component',
  imports: [],
  templateUrl: './field-render-component.html',
  styleUrl: './field-render-component.css',
})
export class FieldRenderComponent {

}
